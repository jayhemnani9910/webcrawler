/* WARNING: Script requires that SQLITE_DBCONFIG_DEFENSIVE be disabled */
PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE Sites (
        id INTEGER PRIMARY KEY,
        root_url TEXT UNIQUE,
        normalized_root TEXT,
        active INTEGER DEFAULT 1,
        last_crawled TEXT,
        status TEXT,
        robots_txt TEXT,
        crawl_delay INTEGER DEFAULT 1
    , user_agent TEXT);
INSERT INTO Sites VALUES(1,'https://www.anthropic.com','https://anthropic.com',1,NULL,'error',replace('User-Agent: *\nAllow: /\n\nSitemap: https://www.anthropic.com/sitemap.xml\n','\n',char(10)),1,NULL);
CREATE TABLE Pages (
        id INTEGER PRIMARY KEY,
        site_id INTEGER,
        url TEXT,
        normalized_url TEXT UNIQUE,
        status TEXT,
        last_archived TEXT,
        FOREIGN KEY(site_id) REFERENCES Sites(id) ON DELETE CASCADE
    );
INSERT INTO Pages VALUES(1,1,'https://www.anthropic.com/news/maryland-partnership','https://anthropic.com/news/maryland-partnership','pending',NULL);
INSERT INTO Pages VALUES(2,1,'https://www.anthropic.com/research/measuring-faithfulness-in-chain-of-thought-reasoning','https://anthropic.com/research/measuring-faithfulness-in-chain-of-thought-reasoning','pending',NULL);
INSERT INTO Pages VALUES(3,1,'https://www.anthropic.com/legal/data-processing-addendum','https://anthropic.com/legal/data-processing-addendum','pending',NULL);
INSERT INTO Pages VALUES(4,1,'https://www.anthropic.com/news/paris-ai-summit','https://anthropic.com/news/paris-ai-summit','pending',NULL);
INSERT INTO Pages VALUES(5,1,'https://www.anthropic.com/research/end-subset-conversations','https://anthropic.com/research/end-subset-conversations','pending',NULL);
INSERT INTO Pages VALUES(6,1,'https://www.anthropic.com/news/rahul-patil-joins-anthropic','https://anthropic.com/news/rahul-patil-joins-anthropic','pending',NULL);
INSERT INTO Pages VALUES(7,1,'https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills','https://anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills','pending',NULL);
INSERT INTO Pages VALUES(8,1,'https://www.anthropic.com/research/evaluating-ai-systems','https://anthropic.com/research/evaluating-ai-systems','pending',NULL);
INSERT INTO Pages VALUES(9,1,'https://www.anthropic.com/news/claudes-constitution','https://anthropic.com/news/claudes-constitution','pending',NULL);
INSERT INTO Pages VALUES(10,1,'https://www.anthropic.com/news/ai-for-science-program','https://anthropic.com/news/ai-for-science-program','pending',NULL);
INSERT INTO Pages VALUES(11,1,'https://www.anthropic.com/news/anthropic-amazon','https://anthropic.com/news/anthropic-amazon','pending',NULL);
INSERT INTO Pages VALUES(12,1,'https://www.anthropic.com/news/salesforce-anthropic-expanded-partnership','https://anthropic.com/news/salesforce-anthropic-expanded-partnership','pending',NULL);
INSERT INTO Pages VALUES(13,1,'https://www.anthropic.com/news/expanded-legal-protections-api-improvements','https://anthropic.com/news/expanded-legal-protections-api-improvements','pending',NULL);
INSERT INTO Pages VALUES(14,1,'https://www.anthropic.com/news/claude-3-5-sonnet','https://anthropic.com/news/claude-3-5-sonnet','pending',NULL);
INSERT INTO Pages VALUES(15,1,'https://www.anthropic.com/legal/credit-terms','https://anthropic.com/legal/credit-terms','pending',NULL);
INSERT INTO Pages VALUES(16,1,'https://www.anthropic.com/research/building-ai-cyber-defenders','https://anthropic.com/research/building-ai-cyber-defenders','pending',NULL);
INSERT INTO Pages VALUES(17,1,'https://www.anthropic.com/events/seoul-builder-summit','https://anthropic.com/events/seoul-builder-summit','pending',NULL);
INSERT INTO Pages VALUES(18,1,'https://www.anthropic.com/startup-program-official-terms','https://anthropic.com/startup-program-official-terms','pending',NULL);
INSERT INTO Pages VALUES(19,1,'https://www.anthropic.com/ai-for-science-program-rules','https://anthropic.com/ai-for-science-program-rules','pending',NULL);
INSERT INTO Pages VALUES(20,1,'https://www.anthropic.com/news/skt-partnership-announcement','https://anthropic.com/news/skt-partnership-announcement','pending',NULL);
INSERT INTO Pages VALUES(21,1,'https://www.anthropic.com/news/the-long-term-benefit-trust','https://anthropic.com/news/the-long-term-benefit-trust','pending',NULL);
INSERT INTO Pages VALUES(22,1,'https://www.anthropic.com/events/google-cloud-next-2025','https://anthropic.com/events/google-cloud-next-2025','pending',NULL);
INSERT INTO Pages VALUES(23,1,'https://www.anthropic.com/news/disrupting-AI-espionage','https://anthropic.com/news/disrupting-AI-espionage','pending',NULL);
INSERT INTO Pages VALUES(24,1,'https://www.anthropic.com/news/introducing-claude','https://anthropic.com/news/introducing-claude','pending',NULL);
INSERT INTO Pages VALUES(25,1,'https://www.anthropic.com/research/economic-policy-responses','https://anthropic.com/research/economic-policy-responses','pending',NULL);
INSERT INTO Pages VALUES(26,1,'https://www.anthropic.com/research/training-a-helpful-and-harmless-assistant-with-reinforcement-learning-from-human-feedback','https://anthropic.com/research/training-a-helpful-and-harmless-assistant-with-reinforcement-learning-from-human-feedback','pending',NULL);
INSERT INTO Pages VALUES(27,1,'https://www.anthropic.com/news/rwandan-government-partnership-ai-education','https://anthropic.com/news/rwandan-government-partnership-ai-education','pending',NULL);
INSERT INTO Pages VALUES(28,1,'https://www.anthropic.com/news/anthropic-is-endorsing-sb-53','https://anthropic.com/news/anthropic-is-endorsing-sb-53','pending',NULL);
INSERT INTO Pages VALUES(29,1,'https://www.anthropic.com/research/interpretability-dreams','https://anthropic.com/research/interpretability-dreams','pending',NULL);
INSERT INTO Pages VALUES(30,1,'https://www.anthropic.com/news/thoughts-on-america-s-ai-action-plan','https://anthropic.com/news/thoughts-on-america-s-ai-action-plan','pending',NULL);
INSERT INTO Pages VALUES(31,1,'https://www.anthropic.com/news/golden-gate-claude','https://anthropic.com/news/golden-gate-claude','pending',NULL);
INSERT INTO Pages VALUES(32,1,'https://www.anthropic.com/news/national-security-expert-richard-fontaine-appointed-to-anthropic-s-long-term-benefit-trust','https://anthropic.com/news/national-security-expert-richard-fontaine-appointed-to-anthropic-s-long-term-benefit-trust','pending',NULL);
INSERT INTO Pages VALUES(33,1,'https://www.anthropic.com/news/updates-to-our-consumer-terms','https://anthropic.com/news/updates-to-our-consumer-terms','pending',NULL);
INSERT INTO Pages VALUES(34,1,'https://www.anthropic.com/research/towards-understanding-sycophancy-in-language-models','https://anthropic.com/research/towards-understanding-sycophancy-in-language-models','pending',NULL);
INSERT INTO Pages VALUES(35,1,'https://www.anthropic.com/news/political-even-handedness','https://anthropic.com/news/political-even-handedness','pending',NULL);
INSERT INTO Pages VALUES(36,1,'https://www.anthropic.com/news/offering-expanded-claude-access-across-all-three-branches-of-government','https://anthropic.com/news/offering-expanded-claude-access-across-all-three-branches-of-government','pending',NULL);
INSERT INTO Pages VALUES(37,1,'https://www.anthropic.com/research/predictability-and-surprise-in-large-generative-models','https://anthropic.com/research/predictability-and-surprise-in-large-generative-models','pending',NULL);
INSERT INTO Pages VALUES(38,1,'https://www.anthropic.com/news/federal-government-departments-and-agencies-can-now-purchase-claude-through-the-gsa-schedule','https://anthropic.com/news/federal-government-departments-and-agencies-can-now-purchase-claude-through-the-gsa-schedule','pending',NULL);
INSERT INTO Pages VALUES(39,1,'https://console.anthropic.com','https://anthropic.com/','pending',NULL);
INSERT INTO Pages VALUES(40,1,'https://www.anthropic.com/news/uk-ai-safety-summit','https://anthropic.com/news/uk-ai-safety-summit','pending',NULL);
INSERT INTO Pages VALUES(41,1,'https://www.anthropic.com/research/decomposing-language-models-into-understandable-components','https://anthropic.com/research/decomposing-language-models-into-understandable-components','pending',NULL);
INSERT INTO Pages VALUES(42,1,'https://www.anthropic.com/economic-futures','https://anthropic.com/economic-futures','pending',NULL);
INSERT INTO Pages VALUES(43,1,'https://www.anthropic.com/news/anthropic-partners-with-u-s-national-labs-for-first-1-000-scientist-ai-jam','https://anthropic.com/news/anthropic-partners-with-u-s-national-labs-for-first-1-000-scientist-ai-jam','pending',NULL);
INSERT INTO Pages VALUES(44,1,'https://www.anthropic.com/research/circuits-updates-april-2024','https://anthropic.com/research/circuits-updates-april-2024','pending',NULL);
INSERT INTO Pages VALUES(45,1,'https://www.anthropic.com/news/claude-opus-4-5','https://anthropic.com/news/claude-opus-4-5','pending',NULL);
INSERT INTO Pages VALUES(46,1,'https://www.anthropic.com/research/influence-functions','https://anthropic.com/research/influence-functions','pending',NULL);
INSERT INTO Pages VALUES(47,1,'https://www.anthropic.com/research/emergent-misalignment-reward-hacking','https://anthropic.com/research/emergent-misalignment-reward-hacking','pending',NULL);
INSERT INTO Pages VALUES(48,1,'https://www.anthropic.com/research/clio','https://anthropic.com/research/clio','pending',NULL);
INSERT INTO Pages VALUES(49,1,'https://www.anthropic.com/economic-futures/symposium-proposals','https://anthropic.com/economic-futures/symposium-proposals','pending',NULL);
INSERT INTO Pages VALUES(50,1,'https://www.anthropic.com/news/anthropic-education-report-how-university-students-use-claude','https://anthropic.com/news/anthropic-education-report-how-university-students-use-claude','pending',NULL);
INSERT INTO Pages VALUES(51,1,'https://www.anthropic.com/legal/aup','https://anthropic.com/legal/aup','pending',NULL);
INSERT INTO Pages VALUES(52,1,'https://www.anthropic.com/engineering/building-agents-with-the-claude-agent-sdk','https://anthropic.com/engineering/building-agents-with-the-claude-agent-sdk','pending',NULL);
INSERT INTO Pages VALUES(53,1,'https://www.anthropic.com/engineering/claude-code-best-practices','https://anthropic.com/engineering/claude-code-best-practices','pending',NULL);
INSERT INTO Pages VALUES(54,1,'https://www.anthropic.com/news/claude-in-xcode','https://anthropic.com/news/claude-in-xcode','pending',NULL);
INSERT INTO Pages VALUES(55,1,'https://www.anthropic.com/news/elections-ai-2024','https://anthropic.com/news/elections-ai-2024','pending',NULL);
INSERT INTO Pages VALUES(56,1,'https://www.anthropic.com/news/the-case-for-targeted-regulation','https://anthropic.com/news/the-case-for-targeted-regulation','pending',NULL);
INSERT INTO Pages VALUES(57,1,'https://www.anthropic.com/news/anthropic-amazon-trainium','https://anthropic.com/news/anthropic-amazon-trainium','pending',NULL);
INSERT INTO Pages VALUES(58,1,'https://www.anthropic.com/news/anthropic-signs-pledge-to-americas-youth-investing-in-ai-education','https://anthropic.com/news/anthropic-signs-pledge-to-americas-youth-investing-in-ai-education','pending',NULL);
INSERT INTO Pages VALUES(59,1,'https://www.anthropic.com/engineering/claude-think-tool','https://anthropic.com/engineering/claude-think-tool','pending',NULL);
INSERT INTO Pages VALUES(60,1,'https://www.anthropic.com/legal/cookies','https://anthropic.com/legal/cookies','pending',NULL);
INSERT INTO Pages VALUES(61,1,'https://www.anthropic.com/news/anthropic-raises-series-e-at-usd61-5b-post-money-valuation','https://anthropic.com/news/anthropic-raises-series-e-at-usd61-5b-post-money-valuation','pending',NULL);
INSERT INTO Pages VALUES(62,1,'https://www.anthropic.com/news/expanding-access-to-claude-for-government','https://anthropic.com/news/expanding-access-to-claude-for-government','pending',NULL);
INSERT INTO Pages VALUES(63,1,'https://www.anthropic.com/research/features-as-classifiers','https://anthropic.com/research/features-as-classifiers','pending',NULL);
INSERT INTO Pages VALUES(64,1,'https://www.anthropic.com/unsubscribe','https://anthropic.com/unsubscribe','pending',NULL);
INSERT INTO Pages VALUES(65,1,'https://www.anthropic.com/news/enabling-claude-code-to-work-more-autonomously','https://anthropic.com/news/enabling-claude-code-to-work-more-autonomously','pending',NULL);
INSERT INTO Pages VALUES(66,1,'https://www.anthropic.com/research/sabotage-evaluations','https://anthropic.com/research/sabotage-evaluations','pending',NULL);
INSERT INTO Pages VALUES(67,1,'https://www.anthropic.com/engineering/contextual-retrieval','https://anthropic.com/engineering/contextual-retrieval','pending',NULL);
INSERT INTO Pages VALUES(68,1,'https://www.anthropic.com/news/anthropic-achieves-iso-42001-certification-for-responsible-ai','https://anthropic.com/news/anthropic-achieves-iso-42001-certification-for-responsible-ai','pending',NULL);
INSERT INTO Pages VALUES(69,1,'https://www.anthropic.com/news/updating-restrictions-of-sales-to-unsupported-regions','https://anthropic.com/news/updating-restrictions-of-sales-to-unsupported-regions','pending',NULL);
INSERT INTO Pages VALUES(70,1,'https://www.anthropic.com/economic-futures/program','https://anthropic.com/economic-futures/program','pending',NULL);
INSERT INTO Pages VALUES(71,1,'https://www.anthropic.com/research/economic-index-geography','https://anthropic.com/research/economic-index-geography','pending',NULL);
INSERT INTO Pages VALUES(72,1,'https://www.anthropic.com/news/introducing-the-anthropic-national-security-and-public-sector-advisory-council','https://anthropic.com/news/introducing-the-anthropic-national-security-and-public-sector-advisory-council','pending',NULL);
INSERT INTO Pages VALUES(73,1,'https://www.anthropic.com/events/aws-summit-london','https://anthropic.com/events/aws-summit-london','pending',NULL);
INSERT INTO Pages VALUES(74,1,'https://www.anthropic.com/legal/referral-partner-program-terms','https://anthropic.com/legal/referral-partner-program-terms','pending',NULL);
INSERT INTO Pages VALUES(75,1,'https://www.anthropic.com/news/a-new-initiative-for-developing-third-party-model-evaluations','https://anthropic.com/news/a-new-initiative-for-developing-third-party-model-evaluations','pending',NULL);
INSERT INTO Pages VALUES(76,1,'https://www.anthropic.com/news/anthropic-signs-cms-health-tech-ecosystem-pledge-to-advance-healthcare-interoperability','https://anthropic.com/news/anthropic-signs-cms-health-tech-ecosystem-pledge-to-advance-healthcare-interoperability','pending',NULL);
INSERT INTO Pages VALUES(77,1,'https://www.anthropic.com/news/introducing-claude-to-canada','https://anthropic.com/news/introducing-claude-to-canada','pending',NULL);
INSERT INTO Pages VALUES(78,1,'https://www.anthropic.com/news/anthropic-raises-series-b-to-build-safe-reliable-ai','https://anthropic.com/news/anthropic-raises-series-b-to-build-safe-reliable-ai','pending',NULL);
INSERT INTO Pages VALUES(79,1,'https://www.anthropic.com/research/exploring-model-welfare','https://anthropic.com/research/exploring-model-welfare','pending',NULL);
INSERT INTO Pages VALUES(80,1,'https://www.anthropic.com/research/question-decomposition-improves-the-faithfulness-of-model-generated-reasoning','https://anthropic.com/research/question-decomposition-improves-the-faithfulness-of-model-generated-reasoning','pending',NULL);
INSERT INTO Pages VALUES(81,1,'https://www.anthropic.com/research/forecasting-rare-behaviors','https://anthropic.com/research/forecasting-rare-behaviors','pending',NULL);
INSERT INTO Pages VALUES(82,1,'https://www.anthropic.com/research/mapping-mind-language-model','https://anthropic.com/research/mapping-mind-language-model','pending',NULL);
INSERT INTO Pages VALUES(83,1,'https://www.anthropic.com/news/investing-in-energy-to-secure-america-s-ai-future','https://anthropic.com/news/investing-in-energy-to-secure-america-s-ai-future','pending',NULL);
INSERT INTO Pages VALUES(84,1,'https://www.anthropic.com/news/claude-3-family','https://anthropic.com/news/claude-3-family','pending',NULL);
INSERT INTO Pages VALUES(85,1,'https://www.anthropic.com/learn','https://anthropic.com/learn','pending',NULL);
INSERT INTO Pages VALUES(86,1,'https://www.anthropic.com/news/mike-krieger-joins-anthropic','https://anthropic.com/news/mike-krieger-joins-anthropic','pending',NULL);
INSERT INTO Pages VALUES(87,1,'https://www.anthropic.com/news/anthropic-series-c','https://anthropic.com/news/anthropic-series-c','pending',NULL);
INSERT INTO Pages VALUES(88,1,'https://www.anthropic.com/news/claude-for-financial-services','https://anthropic.com/news/claude-for-financial-services','pending',NULL);
INSERT INTO Pages VALUES(89,1,'https://www.anthropic.com/research/team/alignment','https://anthropic.com/research/team/alignment','pending',NULL);
INSERT INTO Pages VALUES(90,1,'https://www.anthropic.com/news/anthropic-expands-global-leadership-in-enterprise-ai-naming-chris-ciauri-as-managing-director-of','https://anthropic.com/news/anthropic-expands-global-leadership-in-enterprise-ai-naming-chris-ciauri-as-managing-director-of','pending',NULL);
INSERT INTO Pages VALUES(91,1,'https://www.anthropic.com/news/introducing-claude-for-education','https://anthropic.com/news/introducing-claude-for-education','pending',NULL);
INSERT INTO Pages VALUES(92,1,'https://www.anthropic.com/research/open-source-circuit-tracing','https://anthropic.com/research/open-source-circuit-tracing','pending',NULL);
INSERT INTO Pages VALUES(93,1,'https://www.anthropic.com/research/circuits-updates-august-2024','https://anthropic.com/research/circuits-updates-august-2024','pending',NULL);
INSERT INTO Pages VALUES(94,1,'https://www.anthropic.com/research/swe-bench-sonnet','https://anthropic.com/research/swe-bench-sonnet','pending',NULL);
INSERT INTO Pages VALUES(95,1,'https://www.anthropic.com/news/how-people-use-claude-for-support-advice-and-companionship','https://anthropic.com/news/how-people-use-claude-for-support-advice-and-companionship','pending',NULL);
INSERT INTO Pages VALUES(96,1,'https://www.anthropic.com/news','https://anthropic.com/news','pending',NULL);
INSERT INTO Pages VALUES(97,1,'https://www.anthropic.com/news/releasing-claude-instant-1-2','https://anthropic.com/news/releasing-claude-instant-1-2','pending',NULL);
INSERT INTO Pages VALUES(98,1,'https://www.anthropic.com/news/anthropic-higher-education-initiatives','https://anthropic.com/news/anthropic-higher-education-initiatives','pending',NULL);
INSERT INTO Pages VALUES(99,1,'https://www.anthropic.com/news/claude-brazil','https://anthropic.com/news/claude-brazil','pending',NULL);
INSERT INTO Pages VALUES(100,1,'https://www.anthropic.com/research/towards-monosemanticity-decomposing-language-models-with-dictionary-learning','https://anthropic.com/research/towards-monosemanticity-decomposing-language-models-with-dictionary-learning','pending',NULL);
INSERT INTO Pages VALUES(101,1,'https://www.anthropic.com/news/3-5-models-and-computer-use','https://anthropic.com/news/3-5-models-and-computer-use','pending',NULL);
INSERT INTO Pages VALUES(102,1,'https://www.anthropic.com/legal/trademark-guidelines','https://anthropic.com/legal/trademark-guidelines','pending',NULL);
INSERT INTO Pages VALUES(103,1,'https://www.anthropic.com/engineering/building-effective-agents','https://anthropic.com/engineering/building-effective-agents','pending',NULL);
INSERT INTO Pages VALUES(104,1,'https://www.anthropic.com/research/team/societal-impacts','https://anthropic.com/research/team/societal-impacts','pending',NULL);
INSERT INTO Pages VALUES(105,1,'https://www.anthropic.com/news/cognizant-partnership','https://anthropic.com/news/cognizant-partnership','pending',NULL);
INSERT INTO Pages VALUES(106,1,'https://www.anthropic.com/careers','https://anthropic.com/careers','pending',NULL);
INSERT INTO Pages VALUES(107,1,'https://www.anthropic.com/research/anthropic-economic-index-september-2025-report','https://anthropic.com/research/anthropic-economic-index-september-2025-report','pending',NULL);
INSERT INTO Pages VALUES(108,1,'https://www.anthropic.com/news/claude-2','https://anthropic.com/news/claude-2','pending',NULL);
INSERT INTO Pages VALUES(109,1,'https://www.anthropic.com/news/salesforce-partnership','https://anthropic.com/news/salesforce-partnership','pending',NULL);
INSERT INTO Pages VALUES(110,1,'https://www.anthropic.com/research/discovering-language-model-behaviors-with-model-written-evaluations','https://anthropic.com/research/discovering-language-model-behaviors-with-model-written-evaluations','pending',NULL);
INSERT INTO Pages VALUES(111,1,'https://www.anthropic.com/news/expanding-our-use-of-google-cloud-tpus-and-services','https://anthropic.com/news/expanding-our-use-of-google-cloud-tpus-and-services','pending',NULL);
INSERT INTO Pages VALUES(112,1,'https://www.anthropic.com/research/sleeper-agents-training-deceptive-llms-that-persist-through-safety-training','https://anthropic.com/research/sleeper-agents-training-deceptive-llms-that-persist-through-safety-training','pending',NULL);
INSERT INTO Pages VALUES(113,1,'https://www.anthropic.com/news/building-safeguards-for-claude','https://anthropic.com/news/building-safeguards-for-claude','pending',NULL);
INSERT INTO Pages VALUES(114,1,'https://www.anthropic.com/legal/commercial-terms','https://anthropic.com/legal/commercial-terms','pending',NULL);
INSERT INTO Pages VALUES(115,1,'https://www.anthropic.com/news/microsoft-nvidia-anthropic-announce-strategic-partnerships','https://anthropic.com/news/microsoft-nvidia-anthropic-announce-strategic-partnerships','pending',NULL);
INSERT INTO Pages VALUES(116,1,'https://www.anthropic.com/news/charting-a-path-to-ai-accountability','https://anthropic.com/news/charting-a-path-to-ai-accountability','pending',NULL);
INSERT INTO Pages VALUES(117,1,'https://www.anthropic.com/research/introspection','https://anthropic.com/research/introspection','pending',NULL);
INSERT INTO Pages VALUES(118,1,'https://www.anthropic.com/news/developing-computer-use','https://anthropic.com/news/developing-computer-use','pending',NULL);
INSERT INTO Pages VALUES(119,1,'https://www.anthropic.com/news/core-views-on-ai-safety','https://anthropic.com/news/core-views-on-ai-safety','pending',NULL);
INSERT INTO Pages VALUES(120,1,'https://www.anthropic.com/news/claude-2-1','https://anthropic.com/news/claude-2-1','pending',NULL);
INSERT INTO Pages VALUES(121,1,'https://www.anthropic.com/news/100k-context-windows','https://anthropic.com/news/100k-context-windows','pending',NULL);
INSERT INTO Pages VALUES(122,1,'https://www.anthropic.com/research/estimating-productivity-gains','https://anthropic.com/research/estimating-productivity-gains','pending',NULL);
INSERT INTO Pages VALUES(123,1,'https://www.anthropic.com/research/shade-arena-sabotage-monitoring','https://anthropic.com/research/shade-arena-sabotage-monitoring','pending',NULL);
INSERT INTO Pages VALUES(124,1,'https://www.anthropic.com/news/introducing-anthropic-transparency-hub','https://anthropic.com/news/introducing-anthropic-transparency-hub','pending',NULL);
INSERT INTO Pages VALUES(125,1,'https://www.anthropic.com/research/crosscoder-model-diffing','https://anthropic.com/research/crosscoder-model-diffing','pending',NULL);
INSERT INTO Pages VALUES(126,1,'https://www.anthropic.com/news/jay-kreps-appointed-to-board-of-directors','https://anthropic.com/news/jay-kreps-appointed-to-board-of-directors','pending',NULL);
INSERT INTO Pages VALUES(127,1,'https://www.anthropic.com/rsp-updates','https://anthropic.com/rsp-updates','pending',NULL);
INSERT INTO Pages VALUES(128,1,'https://www.anthropic.com/company','https://anthropic.com/company','pending',NULL);
INSERT INTO Pages VALUES(129,1,'https://www.anthropic.com/engineering/swe-bench-sonnet','https://anthropic.com/engineering/swe-bench-sonnet','pending',NULL);
INSERT INTO Pages VALUES(130,1,'https://www.anthropic.com/research/prompt-injection-defenses','https://anthropic.com/research/prompt-injection-defenses','pending',NULL);
INSERT INTO Pages VALUES(131,1,'https://www.anthropic.com/news/krishna-rao-joins-anthropic','https://anthropic.com/news/krishna-rao-joins-anthropic','pending',NULL);
INSERT INTO Pages VALUES(132,1,'https://www.anthropic.com/news/projects','https://anthropic.com/news/projects','pending',NULL);
INSERT INTO Pages VALUES(133,1,'https://www.anthropic.com/news/Introducing-code-with-claude','https://anthropic.com/news/Introducing-code-with-claude','pending',NULL);
INSERT INTO Pages VALUES(134,1,'https://www.anthropic.com/news/claude-4','https://anthropic.com/news/claude-4','pending',NULL);
INSERT INTO Pages VALUES(135,1,'https://www.anthropic.com/claude/haiku','https://anthropic.com/claude/haiku','pending',NULL);
INSERT INTO Pages VALUES(136,1,'https://www.anthropic.com/events/aws-summit-dc','https://anthropic.com/events/aws-summit-dc','pending',NULL);
INSERT INTO Pages VALUES(137,1,'https://www.anthropic.com/news/anthropic-s-recommendations-ostp-u-s-ai-action-plan','https://anthropic.com/news/anthropic-s-recommendations-ostp-u-s-ai-action-plan','pending',NULL);
INSERT INTO Pages VALUES(138,1,'https://www.anthropic.com/news/anthropic-raises-124-million-to-build-more-reliable-general-ai-systems','https://anthropic.com/news/anthropic-raises-124-million-to-build-more-reliable-general-ai-systems','pending',NULL);
INSERT INTO Pages VALUES(139,1,'https://www.anthropic.com/news/our-framework-for-developing-safe-and-trustworthy-agents','https://anthropic.com/news/our-framework-for-developing-safe-and-trustworthy-agents','pending',NULL);
INSERT INTO Pages VALUES(140,1,'https://www.anthropic.com/research/impact-software-development','https://anthropic.com/research/impact-software-development','pending',NULL);
INSERT INTO Pages VALUES(141,1,'https://www.anthropic.com/news/anthropics-responsible-scaling-policy','https://anthropic.com/news/anthropics-responsible-scaling-policy','pending',NULL);
INSERT INTO Pages VALUES(142,1,'https://www.anthropic.com/events/aws-summit-nyc','https://anthropic.com/events/aws-summit-nyc','pending',NULL);
INSERT INTO Pages VALUES(143,1,'https://www.anthropic.com/news/prompting-long-context','https://anthropic.com/news/prompting-long-context','pending',NULL);
INSERT INTO Pages VALUES(144,1,'https://www.anthropic.com/news/introducing-the-anthropic-economic-advisory-council','https://anthropic.com/news/introducing-the-anthropic-economic-advisory-council','pending',NULL);
INSERT INTO Pages VALUES(145,1,'https://www.anthropic.com/news/detecting-countering-misuse-aug-2025','https://anthropic.com/news/detecting-countering-misuse-aug-2025','pending',NULL);
INSERT INTO Pages VALUES(146,1,'https://www.anthropic.com/news/strategic-warning-for-ai-risk-progress-and-insights-from-our-frontier-red-team','https://anthropic.com/news/strategic-warning-for-ai-risk-progress-and-insights-from-our-frontier-red-team','pending',NULL);
INSERT INTO Pages VALUES(147,1,'https://www.anthropic.com/research/red-teaming-language-models-to-reduce-harms-methods-scaling-behaviors-and-lessons-learned','https://anthropic.com/research/red-teaming-language-models-to-reduce-harms-methods-scaling-behaviors-and-lessons-learned','pending',NULL);
INSERT INTO Pages VALUES(148,1,'https://www.anthropic.com/news/claude-gov-models-for-u-s-national-security-customers','https://anthropic.com/news/claude-gov-models-for-u-s-national-security-customers','pending',NULL);
INSERT INTO Pages VALUES(149,1,'https://www.anthropic.com/news/anthropic-raises-series-f-at-usd183b-post-money-valuation','https://anthropic.com/news/anthropic-raises-series-f-at-usd183b-post-money-valuation','pending',NULL);
INSERT INTO Pages VALUES(150,1,'https://www.anthropic.com/news/strengthening-our-safeguards-through-collaboration-with-us-caisi-and-uk-aisi','https://anthropic.com/news/strengthening-our-safeguards-through-collaboration-with-us-caisi-and-uk-aisi','pending',NULL);
INSERT INTO Pages VALUES(151,1,'https://www.anthropic.com/news/usage-policy-update','https://anthropic.com/news/usage-policy-update','pending',NULL);
INSERT INTO Pages VALUES(152,1,'https://www.anthropic.com/responsible-disclosure-policy','https://anthropic.com/responsible-disclosure-policy','pending',NULL);
INSERT INTO Pages VALUES(153,1,'https://www.anthropic.com/research/many-shot-jailbreaking','https://anthropic.com/research/many-shot-jailbreaking','pending',NULL);
INSERT INTO Pages VALUES(154,1,'https://www.anthropic.com/news/challenges-in-red-teaming-ai-systems','https://anthropic.com/news/challenges-in-red-teaming-ai-systems','pending',NULL);
INSERT INTO Pages VALUES(155,1,'https://www.anthropic.com/economic-index','https://anthropic.com/economic-index','pending',NULL);
INSERT INTO Pages VALUES(156,1,'https://www.anthropic.com/research/distributed-representations-composition-superposition','https://anthropic.com/research/distributed-representations-composition-superposition','pending',NULL);
INSERT INTO Pages VALUES(157,1,'https://www.anthropic.com/research/constitutional-classifiers','https://anthropic.com/research/constitutional-classifiers','pending',NULL);
INSERT INTO Pages VALUES(158,1,'https://www.anthropic.com/research','https://anthropic.com/research','pending',NULL);
INSERT INTO Pages VALUES(159,1,'https://www.anthropic.com/news/advancing-claude-for-financial-services','https://anthropic.com/news/advancing-claude-for-financial-services','pending',NULL);
INSERT INTO Pages VALUES(160,1,'https://www.anthropic.com/research/claude-character','https://anthropic.com/research/claude-character','pending',NULL);
INSERT INTO Pages VALUES(161,1,'https://www.anthropic.com/news/claude-in-amazon-bedrock-fedramp-high','https://anthropic.com/news/claude-in-amazon-bedrock-fedramp-high','pending',NULL);
INSERT INTO Pages VALUES(162,1,'https://www.anthropic.com/news/anthropic-s-response-to-governor-newsom-s-ai-working-group-draft-report','https://anthropic.com/news/anthropic-s-response-to-governor-newsom-s-ai-working-group-draft-report','pending',NULL);
INSERT INTO Pages VALUES(163,1,'https://www.anthropic.com/news/fine-tune-claude-3-haiku','https://anthropic.com/news/fine-tune-claude-3-haiku','pending',NULL);
INSERT INTO Pages VALUES(164,1,'https://www.anthropic.com/research/transformer-circuits','https://anthropic.com/research/transformer-circuits','pending',NULL);
INSERT INTO Pages VALUES(165,1,'https://www.anthropic.com/news/anthropic-bcg','https://anthropic.com/news/anthropic-bcg','pending',NULL);
INSERT INTO Pages VALUES(166,1,'https://www.anthropic.com/research/evaluating-feature-steering','https://anthropic.com/research/evaluating-feature-steering','pending',NULL);
INSERT INTO Pages VALUES(167,1,'https://www.anthropic.com/news/claude-and-alexa-plus','https://anthropic.com/news/claude-and-alexa-plus','pending',NULL);
INSERT INTO Pages VALUES(168,1,'https://www.anthropic.com/news/anthropic-invests-50-billion-in-american-ai-infrastructure','https://anthropic.com/news/anthropic-invests-50-billion-in-american-ai-infrastructure','pending',NULL);
INSERT INTO Pages VALUES(169,1,'https://www.anthropic.com/news/third-party-testing','https://anthropic.com/news/third-party-testing','pending',NULL);
INSERT INTO Pages VALUES(170,1,'https://www.anthropic.com/research/visible-extended-thinking','https://anthropic.com/research/visible-extended-thinking','pending',NULL);
INSERT INTO Pages VALUES(171,1,'https://www.anthropic.com/research/measuring-progress-on-scalable-oversight-for-large-language-models','https://anthropic.com/research/measuring-progress-on-scalable-oversight-for-large-language-models','pending',NULL);
INSERT INTO Pages VALUES(172,1,'https://www.anthropic.com/events','https://anthropic.com/events','pending',NULL);
INSERT INTO Pages VALUES(173,1,'https://www.anthropic.com/news/new-offices-in-paris-and-munich-expand-european-presence','https://anthropic.com/news/new-offices-in-paris-and-munich-expand-european-presence','pending',NULL);
INSERT INTO Pages VALUES(174,1,'https://www.anthropic.com/supported-countries','https://anthropic.com/supported-countries','pending',NULL);
INSERT INTO Pages VALUES(175,1,'https://www.anthropic.com/news/detecting-and-countering-malicious-uses-of-claude-march-2025','https://anthropic.com/news/detecting-and-countering-malicious-uses-of-claude-march-2025','pending',NULL);
INSERT INTO Pages VALUES(176,1,'https://www.anthropic.com/claude/sonnet','https://anthropic.com/claude/sonnet','pending',NULL);
INSERT INTO Pages VALUES(177,1,'https://www.anthropic.com/news/head-of-EMEA-new-roles','https://anthropic.com/news/head-of-EMEA-new-roles','pending',NULL);
INSERT INTO Pages VALUES(178,1,'https://www.anthropic.com/events/claude-for-finance','https://anthropic.com/events/claude-for-finance','pending',NULL);
INSERT INTO Pages VALUES(179,1,'https://www.anthropic.com/research/circuits-updates-july-2024','https://anthropic.com/research/circuits-updates-july-2024','pending',NULL);
INSERT INTO Pages VALUES(180,1,'https://www.anthropic.com/news/anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations','https://anthropic.com/news/anthropic-and-the-department-of-defense-to-advance-responsible-ai-in-defense-operations','pending',NULL);
INSERT INTO Pages VALUES(181,1,'https://www.anthropic.com/news/anthropic-education-report-how-educators-use-claude','https://anthropic.com/news/anthropic-education-report-how-educators-use-claude','pending',NULL);
INSERT INTO Pages VALUES(182,1,'https://www.anthropic.com/research/building-effective-agents','https://anthropic.com/research/building-effective-agents','pending',NULL);
INSERT INTO Pages VALUES(183,1,'https://www.anthropic.com/news/developing-nuclear-safeguards-for-ai-through-public-private-partnership','https://anthropic.com/news/developing-nuclear-safeguards-for-ai-through-public-private-partnership','pending',NULL);
INSERT INTO Pages VALUES(184,1,'https://www.anthropic.com/engineering/advanced-tool-use','https://anthropic.com/engineering/advanced-tool-use','pending',NULL);
INSERT INTO Pages VALUES(185,1,'https://www.anthropic.com/news/anthropic-economic-index-insights-from-claude-sonnet-3-7','https://anthropic.com/news/anthropic-economic-index-insights-from-claude-sonnet-3-7','pending',NULL);
INSERT INTO Pages VALUES(186,1,'https://www.anthropic.com/news/claude-code-on-team-and-enterprise','https://anthropic.com/news/claude-code-on-team-and-enterprise','pending',NULL);
INSERT INTO Pages VALUES(187,1,'https://www.anthropic.com/research/project-vend-1','https://anthropic.com/research/project-vend-1','pending',NULL);
INSERT INTO Pages VALUES(188,1,'https://www.anthropic.com/news/lyft-announcement','https://anthropic.com/news/lyft-announcement','pending',NULL);
INSERT INTO Pages VALUES(189,1,'https://www.anthropic.com/news/claude-sonnet-4-5','https://anthropic.com/news/claude-sonnet-4-5','pending',NULL);
INSERT INTO Pages VALUES(190,1,'https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents','https://anthropic.com/engineering/effective-context-engineering-for-ai-agents','pending',NULL);
INSERT INTO Pages VALUES(191,1,'https://www.anthropic.com/claude/opus','https://anthropic.com/claude/opus','pending',NULL);
INSERT INTO Pages VALUES(192,1,'https://www.anthropic.com/news/model-safety-bug-bounty','https://anthropic.com/news/model-safety-bug-bounty','pending',NULL);
INSERT INTO Pages VALUES(193,1,'https://www.anthropic.com/research/reasoning-models-dont-say-think','https://anthropic.com/research/reasoning-models-dont-say-think','pending',NULL);
INSERT INTO Pages VALUES(194,1,'https://www.anthropic.com/engineering/writing-tools-for-agents','https://anthropic.com/engineering/writing-tools-for-agents','pending',NULL);
INSERT INTO Pages VALUES(195,1,'https://www.anthropic.com/research/superposition-memorization-and-double-descent','https://anthropic.com/research/superposition-memorization-and-double-descent','pending',NULL);
INSERT INTO Pages VALUES(196,1,'https://www.anthropic.com/engineering/multi-agent-research-system','https://anthropic.com/engineering/multi-agent-research-system','pending',NULL);
INSERT INTO Pages VALUES(197,1,'https://www.anthropic.com/news/preparing-for-global-elections-in-2024','https://anthropic.com/news/preparing-for-global-elections-in-2024','pending',NULL);
INSERT INTO Pages VALUES(198,1,'https://www.anthropic.com/research/a-general-language-assistant-as-a-laboratory-for-alignment','https://anthropic.com/research/a-general-language-assistant-as-a-laboratory-for-alignment','pending',NULL);
INSERT INTO Pages VALUES(199,1,'https://www.anthropic.com/research/reward-tampering','https://anthropic.com/research/reward-tampering','pending',NULL);
INSERT INTO Pages VALUES(200,1,'https://www.anthropic.com/research/towards-measuring-the-representation-of-subjective-global-opinions-in-language-models','https://anthropic.com/research/towards-measuring-the-representation-of-subjective-global-opinions-in-language-models','pending',NULL);
INSERT INTO Pages VALUES(201,1,'https://www.anthropic.com/news/reflections-on-our-responsible-scaling-policy','https://anthropic.com/news/reflections-on-our-responsible-scaling-policy','pending',NULL);
INSERT INTO Pages VALUES(202,1,'https://www.anthropic.com/news/activating-asl3-protections','https://anthropic.com/news/activating-asl3-protections','pending',NULL);
INSERT INTO Pages VALUES(203,1,'https://www.anthropic.com/news/frontier-model-security','https://anthropic.com/news/frontier-model-security','pending',NULL);
INSERT INTO Pages VALUES(204,1,'https://www.anthropic.com/news/testing-and-mitigating-elections-related-risks','https://anthropic.com/news/testing-and-mitigating-elections-related-risks','pending',NULL);
INSERT INTO Pages VALUES(205,1,'https://www.anthropic.com/news/policy-recap-q4-2023','https://anthropic.com/news/policy-recap-q4-2023','pending',NULL);
INSERT INTO Pages VALUES(206,1,'https://www.anthropic.com/engineering/claude-code-sandboxing','https://anthropic.com/engineering/claude-code-sandboxing','pending',NULL);
INSERT INTO Pages VALUES(207,1,'https://www.anthropic.com/news/statement-dario-amodei-american-ai-leadership','https://anthropic.com/news/statement-dario-amodei-american-ai-leadership','pending',NULL);
INSERT INTO Pages VALUES(208,1,'https://www.anthropic.com/news/contextual-retrieval','https://anthropic.com/news/contextual-retrieval','pending',NULL);
INSERT INTO Pages VALUES(209,1,'https://www.anthropic.com/news/the-need-for-transparency-in-frontier-ai','https://anthropic.com/news/the-need-for-transparency-in-frontier-ai','pending',NULL);
INSERT INTO Pages VALUES(210,1,'https://www.anthropic.com/news/accenture-aws-anthropic','https://anthropic.com/news/accenture-aws-anthropic','pending',NULL);
INSERT INTO Pages VALUES(211,1,'http://trust.anthropic.com/','http://anthropic.com/','pending',NULL);
INSERT INTO Pages VALUES(212,1,'https://www.anthropic.com/research/in-context-learning-and-induction-heads','https://anthropic.com/research/in-context-learning-and-induction-heads','pending',NULL);
INSERT INTO Pages VALUES(213,1,'https://www.anthropic.com/news/anthropic-partners-with-the-university-of-chicago-s-becker-friedman-institute-on-ai-economic','https://anthropic.com/news/anthropic-partners-with-the-university-of-chicago-s-becker-friedman-institute-on-ai-economic','pending',NULL);
INSERT INTO Pages VALUES(214,1,'https://www.anthropic.com/learn/claude-for-you','https://anthropic.com/learn/claude-for-you','pending',NULL);
INSERT INTO Pages VALUES(215,1,'https://www.anthropic.com/research/circuits-updates-may-2023','https://anthropic.com/research/circuits-updates-may-2023','pending',NULL);
INSERT INTO Pages VALUES(216,1,'https://www.anthropic.com/research/tracing-thoughts-language-model','https://anthropic.com/research/tracing-thoughts-language-model','pending',NULL);
INSERT INTO Pages VALUES(217,1,'https://www.anthropic.com/research/specific-versus-general-principles-for-constitutional-ai','https://anthropic.com/research/specific-versus-general-principles-for-constitutional-ai','pending',NULL);
INSERT INTO Pages VALUES(218,1,'https://www.anthropic.com/news/model-context-protocol','https://anthropic.com/news/model-context-protocol','pending',NULL);
INSERT INTO Pages VALUES(219,1,'https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents','https://anthropic.com/engineering/effective-harnesses-for-long-running-agents','pending',NULL);
INSERT INTO Pages VALUES(220,1,'https://www.anthropic.com/research/persona-vectors','https://anthropic.com/research/persona-vectors','pending',NULL);
INSERT INTO Pages VALUES(221,1,'https://www.anthropic.com/news/an-ai-policy-tool-for-today-ambitiously-invest-in-nist','https://anthropic.com/news/an-ai-policy-tool-for-today-ambitiously-invest-in-nist','pending',NULL);
INSERT INTO Pages VALUES(222,1,'https://www.anthropic.com/research/values-wild','https://anthropic.com/research/values-wild','pending',NULL);
INSERT INTO Pages VALUES(223,1,'https://www.anthropic.com/research/probes-catch-sleeper-agents','https://anthropic.com/research/probes-catch-sleeper-agents','pending',NULL);
INSERT INTO Pages VALUES(224,1,'https://www.anthropic.com/news/mou-uk-government','https://anthropic.com/news/mou-uk-government','pending',NULL);
INSERT INTO Pages VALUES(225,1,'https://www.anthropic.com/research/studying-large-language-model-generalization-with-influence-functions','https://anthropic.com/research/studying-large-language-model-generalization-with-influence-functions','pending',NULL);
INSERT INTO Pages VALUES(226,1,'https://www.anthropic.com/news/announcing-our-updated-responsible-scaling-policy','https://anthropic.com/news/announcing-our-updated-responsible-scaling-policy','pending',NULL);
INSERT INTO Pages VALUES(227,1,'https://www.anthropic.com/legal/privacy','https://anthropic.com/legal/privacy','pending',NULL);
INSERT INTO Pages VALUES(228,1,'https://www.anthropic.com/news/anthropic-partners-with-google-cloud','https://anthropic.com/news/anthropic-partners-with-google-cloud','pending',NULL);
INSERT INTO Pages VALUES(229,1,'https://www.anthropic.com/research/circuits-updates-sept-2024','https://anthropic.com/research/circuits-updates-sept-2024','pending',NULL);
INSERT INTO Pages VALUES(230,1,'https://www.anthropic.com/news/our-approach-to-understanding-and-addressing-ai-harms','https://anthropic.com/news/our-approach-to-understanding-and-addressing-ai-harms','pending',NULL);
INSERT INTO Pages VALUES(231,1,'https://www.anthropic.com/research/engineering-challenges-interpretability','https://anthropic.com/research/engineering-challenges-interpretability','pending',NULL);
INSERT INTO Pages VALUES(232,1,'https://www.anthropic.com/news/claude-opus-4-1','https://anthropic.com/news/claude-opus-4-1','pending',NULL);
INSERT INTO Pages VALUES(233,1,'https://www.anthropic.com/news/lawrence-livermore-national-laboratory-expands-claude-for-enterprise-to-empower-scientists-and','https://anthropic.com/news/lawrence-livermore-national-laboratory-expands-claude-for-enterprise-to-empower-scientists-and','pending',NULL);
INSERT INTO Pages VALUES(234,1,'https://www.anthropic.com/research/confidential-inference-trusted-vms','https://anthropic.com/research/confidential-inference-trusted-vms','pending',NULL);
INSERT INTO Pages VALUES(235,1,'https://www.anthropic.com/research/deprecation-commitments','https://anthropic.com/research/deprecation-commitments','pending',NULL);
INSERT INTO Pages VALUES(236,1,'https://www.anthropic.com/research/agentic-misalignment','https://anthropic.com/research/agentic-misalignment','pending',NULL);
INSERT INTO Pages VALUES(237,1,'https://www.anthropic.com/research/project-fetch-robot-dog','https://anthropic.com/research/project-fetch-robot-dog','pending',NULL);
INSERT INTO Pages VALUES(238,1,'https://www.anthropic.com/research/circuits-updates-june-2024','https://anthropic.com/research/circuits-updates-june-2024','pending',NULL);
INSERT INTO Pages VALUES(239,1,'https://www.anthropic.com/research/language-models-mostly-know-what-they-know','https://anthropic.com/research/language-models-mostly-know-what-they-know','pending',NULL);
INSERT INTO Pages VALUES(240,1,'https://www.anthropic.com/news/eu-code-practice','https://anthropic.com/news/eu-code-practice','pending',NULL);
INSERT INTO Pages VALUES(241,1,'https://www.anthropic.com/research/evaluating-and-mitigating-discrimination-in-language-model-decisions','https://anthropic.com/research/evaluating-and-mitigating-discrimination-in-language-model-decisions','pending',NULL);
INSERT INTO Pages VALUES(242,1,'https://www.anthropic.com/vc-partner-program-official-terms','https://anthropic.com/vc-partner-program-official-terms','pending',NULL);
INSERT INTO Pages VALUES(243,1,'https://www.anthropic.com/events/aws-summit-tokyo','https://anthropic.com/events/aws-summit-tokyo','pending',NULL);
INSERT INTO Pages VALUES(244,1,'https://www.anthropic.com/legal/consumer-terms','https://anthropic.com/legal/consumer-terms','pending',NULL);
INSERT INTO Pages VALUES(245,1,'https://www.anthropic.com/news/google-vertex-general-availability','https://anthropic.com/news/google-vertex-general-availability','pending',NULL);
INSERT INTO Pages VALUES(246,1,'https://www.anthropic.com/research/privileged-bases-in-the-transformer-residual-stream','https://anthropic.com/research/privileged-bases-in-the-transformer-residual-stream','pending',NULL);
INSERT INTO Pages VALUES(247,1,'https://www.anthropic.com/learn/claude-for-work','https://anthropic.com/learn/claude-for-work','pending',NULL);
INSERT INTO Pages VALUES(248,1,'https://www.anthropic.com/research/team/interpretability','https://anthropic.com/research/team/interpretability','pending',NULL);
INSERT INTO Pages VALUES(249,1,'https://www.anthropic.com/news/claude-pro','https://anthropic.com/news/claude-pro','pending',NULL);
INSERT INTO Pages VALUES(250,1,'https://www.anthropic.com/news/securing-america-s-compute-advantage-anthropic-s-position-on-the-diffusion-rule','https://anthropic.com/news/securing-america-s-compute-advantage-anthropic-s-position-on-the-diffusion-rule','pending',NULL);
INSERT INTO Pages VALUES(251,1,'https://www.anthropic.com/news/economic-futures-uk-europe','https://anthropic.com/news/economic-futures-uk-europe','pending',NULL);
INSERT INTO Pages VALUES(252,1,'https://www.anthropic.com/news/introducing-the-anthropic-economic-futures-program','https://anthropic.com/news/introducing-the-anthropic-economic-futures-program','pending',NULL);
INSERT INTO Pages VALUES(253,1,'https://www.anthropic.com/learn/build-with-claude','https://anthropic.com/learn/build-with-claude','pending',NULL);
INSERT INTO Pages VALUES(254,1,'https://www.anthropic.com/news/head-of-japan-hiring-plans','https://anthropic.com/news/head-of-japan-hiring-plans','pending',NULL);
INSERT INTO Pages VALUES(255,1,'https://www.anthropic.com/research/toy-models-of-superposition','https://anthropic.com/research/toy-models-of-superposition','pending',NULL);
INSERT INTO Pages VALUES(256,1,'https://www.anthropic.com/news/testing-our-safety-defenses-with-a-new-bug-bounty-program','https://anthropic.com/news/testing-our-safety-defenses-with-a-new-bug-bounty-program','pending',NULL);
INSERT INTO Pages VALUES(257,1,'https://www.anthropic.com/news/claude-3-7-sonnet','https://anthropic.com/news/claude-3-7-sonnet','pending',NULL);
INSERT INTO Pages VALUES(258,1,'https://www.anthropic.com/news/advancing-claude-for-education','https://anthropic.com/news/advancing-claude-for-education','pending',NULL);
INSERT INTO Pages VALUES(259,1,'https://www.anthropic.com/news/the-anthropic-economic-index','https://anthropic.com/news/the-anthropic-economic-index','pending',NULL);
INSERT INTO Pages VALUES(260,1,'https://www.anthropic.com/news/paul-smith-to-join-anthropic','https://anthropic.com/news/paul-smith-to-join-anthropic','pending',NULL);
INSERT INTO Pages VALUES(261,1,'https://www.anthropic.com/news/seoul-becomes-third-anthropic-office-in-asia-pacific','https://anthropic.com/news/seoul-becomes-third-anthropic-office-in-asia-pacific','pending',NULL);
INSERT INTO Pages VALUES(262,1,'https://www.anthropic.com/news/partnering-with-scale','https://anthropic.com/news/partnering-with-scale','pending',NULL);
INSERT INTO Pages VALUES(263,1,'https://www.anthropic.com/engineering/a-postmortem-of-three-recent-issues','https://anthropic.com/engineering/a-postmortem-of-three-recent-issues','pending',NULL);
INSERT INTO Pages VALUES(264,1,'https://www.anthropic.com/news/frontier-threats-red-teaming-for-ai-safety','https://anthropic.com/news/frontier-threats-red-teaming-for-ai-safety','pending',NULL);
INSERT INTO Pages VALUES(265,1,'https://www.anthropic.com/news/expanding-global-operations-to-india','https://anthropic.com/news/expanding-global-operations-to-india','pending',NULL);
INSERT INTO Pages VALUES(266,1,'https://www.anthropic.com/legal/service-specific-terms','https://anthropic.com/legal/service-specific-terms','pending',NULL);
INSERT INTO Pages VALUES(267,1,'https://www.anthropic.com/news/child-safety-principles','https://anthropic.com/news/child-safety-principles','pending',NULL);
INSERT INTO Pages VALUES(268,1,'https://www.anthropic.com/research/measuring-model-persuasiveness','https://anthropic.com/research/measuring-model-persuasiveness','pending',NULL);
INSERT INTO Pages VALUES(269,1,'https://www.anthropic.com/legal/non-user-privacy-policy','https://anthropic.com/legal/non-user-privacy-policy','pending',NULL);
INSERT INTO Pages VALUES(270,1,'https://www.anthropic.com/engineering/code-execution-with-mcp','https://anthropic.com/engineering/code-execution-with-mcp','pending',NULL);
INSERT INTO Pages VALUES(271,1,'https://www.anthropic.com/research/the-capacity-for-moral-self-correction-in-large-language-models','https://anthropic.com/research/the-capacity-for-moral-self-correction-in-large-language-models','pending',NULL);
INSERT INTO Pages VALUES(272,1,'https://www.anthropic.com/research/small-samples-poison','https://anthropic.com/research/small-samples-poison','pending',NULL);
INSERT INTO Pages VALUES(273,1,'https://www.anthropic.com/research/auditing-hidden-objectives','https://anthropic.com/research/auditing-hidden-objectives','pending',NULL);
INSERT INTO Pages VALUES(274,1,'https://www.anthropic.com/research/alignment-faking','https://anthropic.com/research/alignment-faking','pending',NULL);
INSERT INTO Pages VALUES(275,1,'https://www.anthropic.com/events/paris-builder-summit','https://anthropic.com/events/paris-builder-summit','pending',NULL);
INSERT INTO Pages VALUES(276,1,'https://www.anthropic.com/news/github-copilot','https://anthropic.com/news/github-copilot','pending',NULL);
INSERT INTO Pages VALUES(277,1,'https://www.anthropic.com/news/claude-in-microsoft-foundry','https://anthropic.com/news/claude-in-microsoft-foundry','pending',NULL);
INSERT INTO Pages VALUES(278,1,'https://www.anthropic.com/news/us-elections-readiness','https://anthropic.com/news/us-elections-readiness','pending',NULL);
INSERT INTO Pages VALUES(279,1,'https://www.anthropic.com/engineering/desktop-extensions','https://anthropic.com/engineering/desktop-extensions','pending',NULL);
INSERT INTO Pages VALUES(280,1,'https://www.anthropic.com/research/collective-constitutional-ai-aligning-a-language-model-with-public-input','https://anthropic.com/research/collective-constitutional-ai-aligning-a-language-model-with-public-input','pending',NULL);
INSERT INTO Pages VALUES(281,1,'https://www.anthropic.com/news/claude-3-haiku','https://anthropic.com/news/claude-3-haiku','pending',NULL);
INSERT INTO Pages VALUES(282,1,'https://www.anthropic.com/research/statistical-approach-to-model-evals','https://anthropic.com/research/statistical-approach-to-model-evals','pending',NULL);
INSERT INTO Pages VALUES(283,1,'https://www.anthropic.com/transparency','https://anthropic.com/transparency','pending',NULL);
INSERT INTO Pages VALUES(284,1,'https://www.anthropic.com/news/opening-our-tokyo-office','https://anthropic.com/news/opening-our-tokyo-office','pending',NULL);
INSERT INTO Pages VALUES(285,1,'https://www.anthropic.com/news/deloitte-anthropic-partnership','https://anthropic.com/news/deloitte-anthropic-partnership','pending',NULL);
INSERT INTO Pages VALUES(286,1,'https://www.anthropic.com/research/scaling-laws-and-interpretability-of-learning-from-repeated-data','https://anthropic.com/research/scaling-laws-and-interpretability-of-learning-from-repeated-data','pending',NULL);
INSERT INTO Pages VALUES(287,1,'https://www.anthropic.com/research/petri-open-source-auditing','https://anthropic.com/research/petri-open-source-auditing','pending',NULL);
INSERT INTO Pages VALUES(288,1,'https://www.anthropic.com/news/claude-haiku-4-5','https://anthropic.com/news/claude-haiku-4-5','pending',NULL);
INSERT INTO Pages VALUES(289,1,'https://www.anthropic.com/candidate-ai-guidance','https://anthropic.com/candidate-ai-guidance','pending',NULL);
INSERT INTO Pages VALUES(290,1,'https://www.anthropic.com/legal/inbound-services-agreement','https://anthropic.com/legal/inbound-services-agreement','pending',NULL);
INSERT INTO Pages VALUES(291,1,'https://www.anthropic.com/news/anthropic-partners-with-menlo-ventures-to-launch-anthology-fund','https://anthropic.com/news/anthropic-partners-with-menlo-ventures-to-launch-anthology-fund','pending',NULL);
INSERT INTO Pages VALUES(292,1,'https://www.anthropic.com/news/anthropic-and-iceland-announce-one-of-the-world-s-first-national-ai-education-pilots','https://anthropic.com/news/anthropic-and-iceland-announce-one-of-the-world-s-first-national-ai-education-pilots','pending',NULL);
INSERT INTO Pages VALUES(293,1,'https://www.anthropic.com/engineering','https://anthropic.com/engineering','pending',NULL);
INSERT INTO Pages VALUES(294,1,'https://www.anthropic.com/research/constitutional-ai-harmlessness-from-ai-feedback','https://anthropic.com/research/constitutional-ai-harmlessness-from-ai-feedback','pending',NULL);
INSERT INTO Pages VALUES(295,1,'https://www.anthropic.com/news/prompt-engineering-for-business-performance','https://anthropic.com/news/prompt-engineering-for-business-performance','pending',NULL);
INSERT INTO Pages VALUES(296,1,'https://www.anthropic.com/news/reed-hastings','https://anthropic.com/news/reed-hastings','pending',NULL);
INSERT INTO Pages VALUES(297,1,'https://www.anthropic.com/research/softmax-linear-units','https://anthropic.com/research/softmax-linear-units','pending',NULL);
INSERT INTO Pages VALUES(298,1,'https://www.anthropic.com/news/build-ai-in-america','https://anthropic.com/news/build-ai-in-america','pending',NULL);
INSERT INTO Pages VALUES(299,1,'https://www.anthropic.com/news/zoom-partnership-and-investment','https://anthropic.com/news/zoom-partnership-and-investment','pending',NULL);
INSERT INTO Pages VALUES(300,1,'https://www.anthropic.com/news/claude-europe','https://anthropic.com/news/claude-europe','pending',NULL);
INSERT INTO Pages VALUES(301,1,'https://www.anthropic.com/news/updating-our-usage-policy','https://anthropic.com/news/updating-our-usage-policy','pending',NULL);
INSERT INTO Pages VALUES(302,1,'https://www.anthropic.com/research/a-mathematical-framework-for-transformer-circuits','https://anthropic.com/research/a-mathematical-framework-for-transformer-circuits','pending',NULL);
INSERT INTO Pages VALUES(303,1,'https://www.anthropic.com/news/claude-for-life-sciences','https://anthropic.com/news/claude-for-life-sciences','pending',NULL);
CREATE TABLE PageVersions (
        id INTEGER PRIMARY KEY,
        site_id INTEGER,
        page_id INTEGER,
        archived_at TEXT,
        content_text TEXT,
        content_hash TEXT,
        image_urls TEXT, archive_source TEXT,
        FOREIGN KEY(site_id) REFERENCES Sites(id),
        FOREIGN KEY(page_id) REFERENCES Pages(id)
    );
INSERT INTO PageVersions VALUES(1,1,1,'2025-11-28T00:00:00Z','TEST TEXT','deadbeef','["https://example.com/img.png"]',NULL);
INSERT INTO PageVersions VALUES(2,1,211,'2025-11-29T01:01:43.931828',replace('At Anthropic, we build AI to serve humanityâs long-term well-being.\nâ\nWhile no one can foresee every outcome AI will have on society, we do know that designing powerful technologies requires both bold steps forward and intentional pauses to consider the effects.\nThatâs why we focus on building tools with human benefit at their foundation, like Claude. Through our daily research, policy work, and product design, we aim to show what responsible AI development looks like in practice.','\n',char(10)),'855f5475f0601f40295ab5ff828c8dbfe4cb51ec0d6e45303d018af52eab8774','["https://cdn.prod.website-files.com/67ce28cfec624e2b733f8a52/68b20290e3cdc5e21abc263f_266bcdf860100973b911d000b9f9beb7_maxresdefault-1.webp", "https://cdn.prod.website-files.com/67ce28cfec624e2b733f8a52/67ed7bd686b6d20bb1cd568c_Hands-Build.svg", "https://cdn.prod.website-files.com/67ce28cfec624e2b733f8a52/67ed7bd72914c76f710d86fc_Hands-Stack.svg", "https://cdn.prod.website-files.com/67ce28cfec624e2b733f8a52/67ed7b8d86b6d20bb1cd1292_Objects-Puzzle.svg"]','{"url": "https://www.anthropic.com", "out_path": "/tmp/anthropic_archivebox_sample/index.html", "out_dir": "/tmp/anthropic_archivebox_sample", "outfile": "/tmp/anthropic_archivebox_sample/index.html", "timestamp": "2025-11-29T01:01:43.931828"}');
CREATE TABLE Changes (
        id INTEGER PRIMARY KEY,
        page_version_old_id INTEGER,
        page_version_new_id INTEGER,
        added_text TEXT,
        removed_text TEXT,
        new_image_urls TEXT,
        detected_at TEXT,
        FOREIGN KEY(page_version_old_id) REFERENCES PageVersions(id),
        FOREIGN KEY(page_version_new_id) REFERENCES PageVersions(id)
    );
PRAGMA writable_schema=ON;
INSERT INTO sqlite_schema(type,name,tbl_name,rootpage,sql)VALUES('table','PageVersionsFTS','PageVersionsFTS',0,'CREATE VIRTUAL TABLE PageVersionsFTS USING fts5(content_text, content_hash, page_version_id UNINDEXED)');
CREATE TABLE IF NOT EXISTS 'PageVersionsFTS_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO PageVersionsFTS_data VALUES(1,X'');
INSERT INTO PageVersionsFTS_data VALUES(10,X'00000000000000');
CREATE TABLE IF NOT EXISTS 'PageVersionsFTS_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS 'PageVersionsFTS_content'(id INTEGER PRIMARY KEY, c0, c1, c2);
CREATE TABLE IF NOT EXISTS 'PageVersionsFTS_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
CREATE TABLE IF NOT EXISTS 'PageVersionsFTS_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO PageVersionsFTS_config VALUES('version',4);
PRAGMA writable_schema=OFF;
COMMIT;
